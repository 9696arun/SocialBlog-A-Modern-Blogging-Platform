// ---------------- HEADER ----------------
function updateHeader() {
    const headerButtons = document.querySelector(".header-buttons");
    if (!headerButtons) return;

    headerButtons.innerHTML = "";
    if (localStorage.getItem("authToken")) {
        headerButtons.innerHTML = `
            <a href="profile.html" class="btn btn-login">👤 Profile</a>
            <a href="create-blog.html" class="btn btn-login">✍️ Write</a>
            <a href="#" onclick="logout()" class="btn btn-primary">Logout</a>
        `;
    } else {
        headerButtons.innerHTML = `
            <a href="login.html" class="btn btn-login">Login</a>
            <a href="signup.html" class="btn btn-primary">Sign Up</a>
        `;
    }
}

function logout() {
    localStorage.removeItem("authToken");
    window.location.href = "index.html";
}

// ---------------- MAIN ----------------
document.addEventListener("DOMContentLoaded", function () {
    updateHeader();

    // ---------------- SIGNUP ----------------
    const signupForm = document.getElementById("signupForm");
    if (signupForm) {
        signupForm.addEventListener("submit", async function (e) {
            e.preventDefault();
            const user = {
                name: document.getElementById("name").value.trim(),
                email: document.getElementById("email").value.trim(),
                password: document.getElementById("password").value.trim()
            };

            try {
                const res = await fetch("http://localhost:5000/api/auth/register", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(user),
                });

                const data = await res.json();
                console.log("Signup Response:", data);

                if (res.ok) {
                    alert("Signup successful! Please login.");
                    window.location.href = "login.html";
                } else {
                    alert(data.error || "Signup failed!");
                }
            } catch (err) {
                console.error("Signup Error:", err);
                alert("Server error, please try again later.");
            }
        });
    }

    // ---------------- LOGIN ----------------
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", async function (e) {
            e.preventDefault();
            const email = document.getElementById("email").value.trim();
            const password = document.getElementById("password").value.trim();

            try {
                const res = await fetch("http://localhost:5000/api/auth/login", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email, password }),
                });

                const data = await res.json();
                console.log("Login Response:", data);

                if (res.ok && data.token) {
                    localStorage.setItem("authToken", data.token);
                    alert("Login successful!");
                    window.location.href = "index.html";
                } else {
                    alert(data.error || "Invalid credentials!");
                }
            } catch (err) {
                console.error("Login Error:", err);
                alert("Server error, please try again later.");
            }
        });
    }

    // ---------------- PROFILE ----------------
    if (document.getElementById("pName")) {
        const token = localStorage.getItem("authToken");
        if (token) {
            fetch("http://localhost:5000/api/users/me", {
                headers: { "Authorization": "Bearer " + token }
            })
                .then(res => res.json())
                .then(user => {
                    if (user.name) {
                        document.getElementById("pName").textContent = user.name;
                        document.getElementById("pEmail").textContent = user.email;
                    } else {
                        alert("Session expired, please login again.");
                        window.location.href = "login.html";
                    }
                })
                .catch(err => console.error("Profile Error:", err));
        }
    }

    // ---------------- EDIT PROFILE ----------------
    const editProfileForm = document.getElementById("editProfileForm");
    if (editProfileForm) {
        const token = localStorage.getItem("authToken");

        if (token) {
            fetch("http://localhost:5000/api/users/me", {
                headers: { "Authorization": "Bearer " + token }
            })
                .then(res => res.json())
                .then(user => {
                    if (user.name) {
                        document.getElementById("editName").value = user.name;
                        document.getElementById("editEmail").value = user.email;
                    }
                });
        }

        editProfileForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const updatedUser = {
                name: document.getElementById("editName").value.trim(),
                email: document.getElementById("editEmail").value.trim(),
            };

            fetch("http://localhost:5000/api/users/me", {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + token
                },
                body: JSON.stringify(updatedUser),
            })
                .then(res => res.json())
                .then(data => {
                    if (data.name) {
                        alert("Profile updated!");
                        window.location.href = "profile.html";
                    } else {
                        alert(data.error || "Update failed");
                    }
                })
                .catch(err => console.error("Edit Profile Error:", err));
        });
    }

    // ---------------- CREATE BLOG ----------------
    const blogForm = document.getElementById("blogForm");
    if (blogForm) {
        blogForm.addEventListener("submit", async function (e) {
            e.preventDefault();
            const title = document.getElementById("title").value.trim();
            const content = document.getElementById("content").value.trim();
            const token = localStorage.getItem("authToken");

            try {
                const res = await fetch("http://localhost:5000/api/blogs", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + token
                    },
                    body: JSON.stringify({ title, content }),
                });

                const data = await res.json();
                if (res.ok && data._id) {
                    alert("Blog published!");
                    window.location.href = "blogs.html";
                } else {
                    alert(data.error || "Failed to publish blog");
                }
            } catch (err) {
                console.error("Create Blog Error:", err);
                alert("Server error, please try again later.");
            }
        });
    }

    // ---------------- SHOW BLOGS ----------------
    const blogsList = document.getElementById("blogsList");
    if (blogsList) {
        fetch("http://localhost:5000/api/blogs")
            .then(res => res.json())
            .then(blogs => {
                if (!Array.isArray(blogs)) {
                    blogsList.innerHTML = "<p>No blogs available.</p>";
                    return;
                }
                blogsList.innerHTML = blogs.map(b => `
                    <div class="blog-card">
                        <h3>${b.title}</h3>
                        <p>${b.content}</p>
                        <small>By ${b.author?.name || "Unknown"}</small>
                    </div>
                `).join("");
            })
            .catch(err => {
                console.error("Fetch Blogs Error:", err);
                blogsList.innerHTML = "<p>Error loading blogs.</p>";
            });
    }
});
