const express = require("express");
const User = require("../models/User");
const auth = require("../middleware/auth");

const router = express.Router();

// Get user profile
router.get("/me", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user).select("-password");
    res.json(user);
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// Update profile
router.put("/me", auth, async (req, res) => {
  try {
    const { name, email } = req.body;
    const user = await User.findByIdAndUpdate(
      req.user,
      { name, email },
      { new: true }
    ).select("-password");
    res.json(user);
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
