const express = require("express");
const Blog = require("../models/blog");
const auth = require("../middleware/auth");

const router = express.Router();

// Create Blog
router.post("/", auth, async (req, res) => {
  try {
    const blog = new Blog({
      title: req.body.title,
      content: req.body.content,
      author: req.user,
    });
    const savedBlog = await blog.save();
    res.json(savedBlog);
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

// Get All Blogs
router.get("/", async (req, res) => {
  try {
    const blogs = await Blog.find().populate("author", "name email");
    res.json(blogs);
  } catch {
    res.status(500).json({ error: "Server error" });
  }
});

module.exports = router;
